<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.0" name="map3" tilewidth="31" tileheight="31" spacing="2" margin="2" tilecount="342" columns="18">
 <image source="map.png" width="626" height="659"/>
</tileset>
