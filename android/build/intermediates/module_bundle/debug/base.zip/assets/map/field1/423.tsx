<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.0" name="423" tilewidth="1" tileheight="1" tilecount="0" columns="0"/>
