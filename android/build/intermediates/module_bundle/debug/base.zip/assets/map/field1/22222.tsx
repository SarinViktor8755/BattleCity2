<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.0" name="map" tilewidth="32" tileheight="32" tilecount="380" columns="19">
 <image source="map.png" width="626" height="659"/>
</tileset>
