<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.0" name="map2222" tilewidth="30" tileheight="30" spacing="2" margin="2" tilecount="380" columns="19">
 <image source="map.png" width="626" height="659"/>
</tileset>
